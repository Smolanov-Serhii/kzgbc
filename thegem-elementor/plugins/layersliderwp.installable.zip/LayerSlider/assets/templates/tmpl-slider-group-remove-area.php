<?php defined( 'LS_ROOT_FILE' ) || exit; ?>
<div id="ls-group-remove-area">
	<div class="ls-drop-area">
		<span class="dashicons dashicons-undo"></span>
		<p data-text="<?php _e("Drag sliders here to \n remove from this folder", 'LayerSlider') ?>" data-drop-text="<?php _e('Drop to remove from folder', 'LayerSlider') ?>"></p>
	</div>
</div>