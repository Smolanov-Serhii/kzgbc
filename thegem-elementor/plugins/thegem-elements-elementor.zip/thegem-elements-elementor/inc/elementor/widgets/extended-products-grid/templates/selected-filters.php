<div class="filter-item portfolio-selected-filters <?php if (isset($settings['duplicate_selected_in_sidebar']) && $settings['duplicate_selected_in_sidebar'] != 'yes') {
	echo 'hide-on-sidebar';
} ?>">
	<div class="filter-item clear-filters">
		<?php echo $settings['filters_text_labels_clear_text']; ?>
	</div>
	<?php if (isset($_GET[$grid_uid . '-category'])) { ?>
		<div class="filter-item category"
			 data-filter="<?php echo $active_cat; ?>"><?php $category = get_term_by('slug', $active_cat, 'product_cat');
			echo $category->name; ?> <i class="delete"></i></div>
	<?php }
	if ($has_attr_url) {
		foreach ($attributes_current as $key => $value) {
			foreach ($value as $attr_value) { ?>
				<div class="filter-item attribute" data-attr="<?php echo $key; ?>"
					 data-filter="<?php echo $attr_value; ?>"><?php $category = get_term_by('slug', $attr_value, 'pa_' . $key);
					echo $category->name; ?><i class="delete"></i></div>
			<?php }
		}
	}
	if (isset($_GET[$grid_uid . '-status'])) {
		if (in_array('sale', $status_current)) { ?>
			<div class="filter-item status" data-filter="sale"><?php echo $settings['filter_by_status_sale_text']; ?><i
						class="delete"></i></div>
		<?php }
		if (in_array('stock', $status_current)) { ?>
			<div class="filter-item status" data-filter="stock"><?php echo $settings['filter_by_status_stock_text']; ?>
				<i class="delete"></i></div>
			<?php
		}
	}
	if (isset($_GET[$grid_uid . '-price'])) {
		$price_current = explode(",", $_GET[$grid_uid . '-price']); ?>
		<div class="filter-item price"><?php echo get_woocommerce_currency_symbol() . $price_current[0] . ' - ' . get_woocommerce_currency_symbol() . $price_current[1]; ?>
			<i class="delete"></i></div>
	<?php }
	if (isset($_GET[$grid_uid . '-search'])) { ?>
		<div class="filter-item search"><?php echo $search_current; ?><i class="delete"></i></div>
	<?php } ?>
</div>